import React from "react";
import "./WelcomePopup.css"; // Make sure to define tooltip styles here.

const WelcomePopup: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  return (
    <div className="overlay">
      <div className="popup">
        <h2>Welcome to Mindful U!</h2>
        <h4>How familiar are you with meditation?</h4>
        <button
          className="btn"
          onClick={onClose}
          title="I’ve never meditated or have tried it only a couple of times."
        >
          Beginner
        </button>
        <button
          className="btn"
          onClick={onClose}
          title="I meditate once in a while, but not regularly."
        >
          Occasional
        </button>
        <button
          className="btn"
          onClick={onClose}
          title="I meditate consistently as part of my routine."
        >
          Regular
        </button>
      </div>
    </div>
  );
};

export default WelcomePopup;
